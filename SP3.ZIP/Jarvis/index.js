function doLogin() {
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", "/Login", true);
    xhttp.setRequestHeader("content-type", "application/json; charset=utf-8");
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200) {
                try {
                    doMsg({ "Action": "Info", "Message": JSON.parse(this.responseText) });
                    document.getElementById("portfolioButton").style.visibility = "visible";
                    document.getElementById("loginButton").style.visibility = "hidden";
                }
                catch (err) {
                    doMsg({ "Action": "Error", "Message": "Error processing request" });
                    return;
                }
            } else {
                doMsg({ "Action": "Error", "Message": this.statusText });
                return
            }
        }
    }
    xhttp.send('{}');
}


function doPortfolio() {
    let portfolio = document.getElementById("portfolio");
    portfolio.innerHTML = "";
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", "/Portfolio", true);
    xhttp.setRequestHeader("content-type", "application/json; charset=utf-8");
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200) {
                try {
                    portfolio.innerHTML = arrayToTable(JSON.parse(this.responseText));
                }
                catch (err) {
                    doMsg({ "Action": "Error", "Message": "Error processing request" });
                    return;
                }
            } else {
                doMsg({ "Action": "Error", "Message": this.statusText });
                return
            }
        }
    }
    xhttp.send("{}");
}

function doMsg(payload) {
    try {
        let msgarea = document.getElementById("msgarea")
        msgarea.innerHTML = payload.Message;
        msgarea.className = payload.Action.toLowerCase();
    } catch (error) {
        console.error(error);
    }
}

function arrayToTable(array) {
    let h = "<table>";
    array.forEach(element => {
        h += "<tr>" + arrayToRow(element) + "</tr>"
    });
    h += "</table>"
    return h;
}

function arrayToRow(row) {
    let h = ""
    row.forEach(element => {
        h += "<td>" + element + "</td>"
    });
    return h;
}