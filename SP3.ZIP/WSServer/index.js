let wsRoot = "ws://localhost:22334";
let ws;

function doLogin() {
    document.getElementById("msgarea").innerHTML = "";
    document.getElementById("portfolio").innerHTML = "";
    let userid = document.getElementById("userid").value.trim();
    let password = document.getElementById("password").value.trim();
    let msg = (0 == userid.length) ? "UserID is missing. " : "";
    msg += (0 == password.length) ? "Password is missing. " : "";
    if (0 == msg.length) {
        makeWebSocket();
        let payload = {};
        payload.Action = "Login";
        payload.UserID = userid;
        payload.Password = password;
        delay(500).then(() => doSend(JSON.stringify(payload)));
    } else {
        doMsg({ "Action": "Error", "Message": msg });
    }
}

function delay(time) {
    return new Promise(resolve => setTimeout(resolve, time));
}

function makeWebSocket() {
    if (!(ws === undefined)){
        ws.close();
    }
    ws = new WebSocket(wsRoot);
    ws.onopen = function (evt) { onOpen(evt) };
    ws.onclose = function (evt) { onClose(evt) };
    ws.onmessage = function (evt) { onMessage(evt) };
    ws.onerror = function (evt) { onError(evt) };
}

function onOpen(evt) {
    console.log("WebSocket opened");
}

function onClose(evt) {
    document.getElementById("status").innerHTML = "Not logged in"
    doMsg({ "Action": "Info", "Message": "" });
    console.log("WebSocket closed");
}

function onMessage(evt) {
    let payload = JSON.parse(evt.data);
    switch (payload.Action) {
        case "Do":
            try {
                eval(payload.Message);
            } catch (error) {
                console.error(error);
            }
            break;
        case "Replace":
            try {
                let elm = document.querySelector(payload.What);
                elm.innerHTML = payload.With;
            } catch (error) {
                console.error(error);
            }
            break;
        case "Append":
            try {
                let elm = document.querySelector(payload.What);
                elm.innerHTML += payload.With;
            } catch (error) {
                console.error(error);
            }
            break;
        case "Prepend":
            try {
                let elm = document.querySelector(payload.What);
                elm.innerHTML = payload.With + elm.innerHTML;
            } catch (error) {
                console.error(error);
            }
            break;
        case "Portfolio":
            try {
                let elm = document.querySelector("#portfolio");
                elm.innerHTML = arrayToTable(payload.Portfolio);
            } catch(error) {
                console.error(error);
            }
            break;
        default:
            doMsg(payload);
    }
}

function doMsg(payload) {
    try {
        let msgarea = document.getElementById("msgarea")
        msgarea.innerHTML = payload.Message;
        msgarea.className = payload.Action.toLowerCase();
    } catch (error) {
        console.error(error);
    }
}

function onError(evt) {
    console.error(evt);
}

function doSend(message) {
    ws.send(message);
}

function arrayToTable(array) {
    let h = "<table>";
    array.forEach(element => {
        h += "<tr>" + arrayToRow(element) + "</tr>"
    });
    h += "</table>"
    return h;
}

function arrayToRow(row) {
    let h = ""
    row.forEach(element => {
        h += "<td>" + element + "</td>"
    });
    return h;
}